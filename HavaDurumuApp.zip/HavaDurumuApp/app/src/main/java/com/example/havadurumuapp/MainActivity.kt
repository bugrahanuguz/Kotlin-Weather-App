package com.example.havadurumuapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.StringRequest
import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        verileriGetir("ankara")

    }
    fun tarihYazdir():String{

        var takvim = Calendar.getInstance().time
        var formatlayici= SimpleDateFormat("d MMMM\n EEEE,\n HH:mm", Locale("tr"))
        var tarih = formatlayici.format(takvim)
        return tarih
    }
    fun verileriGetir(sehir:String){
        var url = "https://api.openweathermap.org/data/2.5/weather?q="+sehir.capitalize()+",tr&appid=15fdef8ddbbfcea3b3b6afc9d13ef6f0&lang=tr&units=metric"
        var havaDurumuObjeRequest =JsonObjectRequest(Request.Method.GET,url,null,object: Response.Listener<JSONObject>{
            override fun onResponse(response: JSONObject?) {
                var main = response!!.getJSONObject("main")
                var sicaklik = main.getInt("temp")
                tvSicaklik.text=sicaklik.toString()
                var nem = main.getInt("humidity")
                tvNem.text="Nem : %${nem.toString()}"
                var sehirAdi = response.getString("name")
                tvSehir.text=sehirAdi
                var weather = response.getJSONArray("weather")
                var aciklama = weather.getJSONObject(0).getString("description")
                tvAciklama.text=aciklama.capitalize()
                var icon = weather.getJSONObject(0).getString("icon")
                if(icon.last()== 'd'){
                    root_layout.background=getDrawable(R.drawable.gunduzz)
                }else {
                    root_layout.background = getDrawable(R.drawable.geceee)
                    tvAciklama.setTextColor(resources.getColor(R.color.purple_500))
                    tvNem.setTextColor(resources.getColor(R.color.purple_500))
                    tvTarih.setTextColor(resources.getColor(R.color.purple_500))
                    tvSehir.setTextColor(resources.getColor(R.color.purple_500))
                    tvSicaklik.setTextColor(resources.getColor(R.color.purple_500))
                    textView4.setTextColor(resources.getColor(R.color.purple_500))
                }

                tvTarih.text=tarihYazdir()

            }
        },object :Response.ErrorListener {

            override fun onErrorResponse(error: VolleyError?) {

            }
        })
        MySingleton.getInstance(this).addToRequestQueue(havaDurumuObjeRequest)
    }

}


